"""
CMake Generator for C/C++ Projects
"""

__version__ = '0.1.0'